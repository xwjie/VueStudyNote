// @flow

function Xiao(options: Object){
	console.log('main start', options);
}

export default Xiao;
